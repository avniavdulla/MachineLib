#include "pch.h"
#include "Const.h"

const double CConst::PI = 3.1415926535897932384626433832795;
const double CConst::PI2 = CConst::PI * 2;