/**
 * \file Shape.cpp
 *
 * \author Avni Avdulla
 */

#include "pch.h"
#include "Shape.h"

CShape::CShape()
{
    mSink.SetComponent(this);
}


